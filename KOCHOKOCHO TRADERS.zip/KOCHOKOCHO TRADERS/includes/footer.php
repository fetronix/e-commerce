<style type="text/css">
    a {
    font-size: 24px;
    color: white;
  }
   a:hover {
    font-size: 24px;
    color: green;
  }
</style>
<div id="footer" style="background-color: #68C768"><!-- #footer Begin -->
    <div class="container"><!-- container Begin -->
        <div class="row"><!-- row Begin -->
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                <ul><!-- ul Begin -->
                    
                    <li><a href="customer_register.php">Register</a></li>
                </ul><!-- ul Finish -->
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                
                <h4>Find Us</h4>
                
                <a href="contact.php">Check Our Contact Page</a>
                
            </div><!-- col-sm-6 col-md-3 Finish -->

            
            
            <div class="col-sm-6 col-md-3">
                
                <p class="social">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-instagram"></a>
                    <a href="#" class="fa fa-google-plus"></a>
                    <a href="#" class="fa fa-envelope"></a>
                </p>
                
            </div>
        </div><!-- row Finish -->
    </div><!-- container Finish -->
</div><!-- #footer Finish -->


<div id="copyright"><!-- #copyright Begin -->
    <div class="container"><!-- container Begin -->
        <div class="col-md-6"><!-- col-md-6 Begin -->
            
            <p class="pull-left" style="color: #52C452;">&copy; 2020 KochoKocho Traders All Rights Reserved</p>
            
        </div><!-- col-md-6 Finish -->
    </div><!-- container Finish -->
</div><!-- #copyright Finish -->